import { CategoryDTO } from "./category";
import { UserBasicDTO } from "./user";
import { BidDTO } from "./bid";

// Main auction interface
export interface AuctionBasicDTO {
  id: number;
  user: UserBasicDTO;
  category: CategoryDTO;
  itemName: string;
  minimumPrice: number;
  status: string;
  createDate: string;
  expiredDate: string;
  lastBid: number | null;
  description: string;
  type: 'FIXED' | 'EXTENDED'; // More specific type
  extraTime: string | null;
  itemState: string;
  tags: string | null;
  minStep: number;
  condition: number;
  images: string[];
  bids?: BidDTO[];
}

// For creating new auctions (simpler version without auto-generated fields)
export interface AuctionCreateDTO {
  itemName: string;
  category: { id: number }; // Only need ID for creation
  minimumPrice: number;
  description: string;
  type: 'FIXED' | 'EXTENDED';
  expiredDate: string;
  extraTime?: string; // Optional since it's only for EXTENDED type
  itemState: string;
  minStep: number;
  condition: number;
  images: string[];
}

// For the card view
export interface AuctionCardDTO {
  id: number;
  itemName: string;
  createDate: string;
  expiredDate: string;
  lastBid: number | null;
  status: string;
}

// Type for form state management
export interface AuctionFormState {
  // Step 1 data (from UploadAuction)
  description: string;
  images: File[]; // Temporary files before upload
  
  // Step 2 data (from SetDetailsAuction)
  itemName: string;
  categoryId: number;
  condition: number;
  itemState: string;
  auctionType: 'FIXED' | 'EXTENDED';
  minimumPrice: number;
  minStep: number;
  expiredDate: string;
  extraTime?: string;
}