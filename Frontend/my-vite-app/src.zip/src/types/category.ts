export interface CategoryDTO {
    id: number
    categoryName: string
  }