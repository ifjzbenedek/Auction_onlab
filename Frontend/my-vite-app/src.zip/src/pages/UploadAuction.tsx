"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import {
  Box,
  Typography,
  Button,
  TextField,
  Paper,
  Grid,
  IconButton,
  Stepper,
  Step,
  StepLabel,
  Alert,
  CircularProgress,
  useTheme,
  alpha,
  Chip,
} from "@mui/material"
import { styled } from "@mui/material/styles"
import { Upload, Plus, ArrowRight, Sparkles, X, ImageIcon, FileText, Camera, Info } from "lucide-react"

interface UploadedImage {
  id: string
  file: File
  preview: string
}

// Styled components
const PageContainer = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.default,
  minHeight: "100vh",
  paddingBottom: theme.spacing(5),
}))

const StepContainer = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: theme.shape.borderRadius * 2,
  boxShadow: "0 8px 30px rgba(0, 0, 0, 0.06)",
  marginBottom: theme.spacing(4),
  position: "relative",
  overflow: "hidden",
}))

const StepTitle = styled(Typography)(({ theme }) => ({
  marginBottom: theme.spacing(3),
  position: "relative",
  display: "inline-block",
  fontWeight: "bold",
  "&:after": {
    content: '""',
    position: "absolute",
    bottom: -8,
    left: 0,
    width: 40,
    height: 4,
    backgroundColor: theme.palette.primary.main,
    borderRadius: 2,
  },
}))

const UploadBox = styled(Box)(({ theme }) => ({
  border: `2px dashed ${alpha(theme.palette.primary.main, 0.3)}`,
  borderRadius: theme.shape.borderRadius * 2,
  padding: theme.spacing(3),
  textAlign: "center",
  backgroundColor: alpha(theme.palette.primary.main, 0.03),
  transition: "all 0.2s ease",
  cursor: "pointer",
  "&:hover": {
    backgroundColor: alpha(theme.palette.primary.main, 0.05),
    borderColor: alpha(theme.palette.primary.main, 0.5),
  },
}))

const ImagePreviewContainer = styled(Box)(({ theme }) => ({
  border: `1px solid ${alpha(theme.palette.divider, 0.6)}`,
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(2),
}))

const ImagePreview = styled(Box)(({ theme }) => ({
  position: "relative",
  width: "100%",
  height: 100,
  borderRadius: theme.shape.borderRadius,
  overflow: "hidden",
}))

const AddImageBox = styled(Box)(({ theme }) => ({
  width: "100%",
  height: 100,
  border: `1px dashed ${alpha(theme.palette.primary.main, 0.4)}`,
  borderRadius: theme.shape.borderRadius,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
  backgroundColor: alpha(theme.palette.primary.main, 0.03),
  transition: "all 0.2s ease",
  "&:hover": {
    backgroundColor: alpha(theme.palette.primary.main, 0.05),
    borderColor: alpha(theme.palette.primary.main, 0.6),
  },
}))

const ActionButton = styled(Button)(({ theme }) => ({
  borderRadius: 30,
  padding: theme.spacing(1.2, 3),
  textTransform: "none",
  fontWeight: 600,
  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
  transition: "transform 0.2s ease",
  "&:hover": {
    transform: "translateY(-2px)",
    boxShadow: "0 6px 16px rgba(0, 0, 0, 0.15)",
  },
}))

const StepIcon = styled(Box)(({ theme }) => ({
  position: "absolute",
  top: -15,
  right: -15,
  width: 80,
  height: 80,
  opacity: 0.07,
  zIndex: 0,
  color: theme.palette.primary.main,
}))

const UploadAuction: React.FC = () => {
  const navigate = useNavigate()
  const theme = useTheme()
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([])
  const [description, setDescription] = useState("")
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isUploading, setIsUploading] = useState(false)

  // Check session storage for previously uploaded data when coming back from SetDetailsAuction
  useEffect(() => {
    const savedData = sessionStorage.getItem("auctionUploadData")
    if (savedData) {
      try {
        const { description } = JSON.parse(savedData)
        setDescription(description)
        // Note: We can't restore image File objects from session storage
        // In a real app, you would need to handle this differently (e.g., temporary server storage)
      } catch (e) {
        console.error("Error parsing saved auction data", e)
      }
    }
  }, [])

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const newFiles = Array.from(event.target.files)

      const newImages = newFiles.map((file) => ({
        id: Math.random().toString(36).substring(2, 9),
        file,
        preview: URL.createObjectURL(file),
      }))

      setUploadedImages([...uploadedImages, ...newImages])
    }
  }

  const handleRemoveImage = (id: string) => {
    const updatedImages = uploadedImages.filter((img) => img.id !== id)
    setUploadedImages(updatedImages)
  }

  const handleAutogenerateDescription = () => {
    setIsGeneratingDescription(true)

    // Simulate AI description generation
    setTimeout(() => {
      const generatedText =
        "This is an automatically generated description based on your uploaded images. " +
        "This item appears to be in excellent condition and would make a great addition to any collection. " +
        "The item shows minimal signs of wear and comes from a smoke-free environment. " +
        "Please review the photos carefully and feel free to ask any questions before bidding."

      setDescription(generatedText)
      setIsGeneratingDescription(false)
    }, 1500)
  }

  const handleContinue = async () => {
    if (uploadedImages.length >= 1 && description.trim().length > 0) {
      setIsUploading(true)

      try {
        // In a real application, you would upload the images to a server here
        // and get back URLs to use in the auction creation
        // For now, we'll simulate this with a timeout and use the preview URLs

        // Simulate image upload delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Get image URLs (in a real app, these would be the URLs returned from the server)
        const imageUrls = uploadedImages.map((img) => img.preview)

        // Save current data to session storage before navigating
        const dataToSave = {
          description,
          images: imageUrls,
        }
        sessionStorage.setItem("auctionUploadData", JSON.stringify(dataToSave))

        // Navigate to the second step
        navigate("/set-details-auction")
      } catch (error) {
        console.error("Error uploading images:", error)
        alert("Failed to upload images. Please try again.")
      } finally {
        setIsUploading(false)
      }
    }
  }

  return (
    <PageContainer>
      <Box sx={{ maxWidth: 1000, mx: "auto", px: { xs: 2, md: 4 }, py: 4 }}>
        <Box sx={{ mb: 4, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Typography variant="h4" fontWeight="bold" color="text.primary">
            Create New Auction
          </Typography>
          <Chip
            label="Step 1 of 2"
            color="primary"
            sx={{
              borderRadius: 5,
              fontWeight: "medium",
              px: 1,
              backgroundColor: alpha(theme.palette.primary.main, 0.1),
              color: theme.palette.primary.main,
            }}
          />
        </Box>

        <Stepper
          activeStep={0}
          sx={{
            mb: 4,
            display: { xs: "none", md: "flex" },
            "& .MuiStepLabel-label": {
              fontWeight: "medium",
            },
            "& .MuiStepLabel-active": {
              fontWeight: "bold",
              color: theme.palette.primary.main,
            },
          }}
        >
          <Step>
            <StepLabel>Upload & Describe</StepLabel>
          </Step>
          <Step>
            <StepLabel>Set Details</StepLabel>
          </Step>
        </Stepper>

        {/* Step 1: Upload photos */}
        <StepContainer>
          <StepIcon>
            <Camera size={80} />
          </StepIcon>

          <StepTitle variant="h5">Upload Photos</StepTitle>

          <UploadBox onClick={() => fileInputRef.current?.click()}>
            <Box
              sx={{
                width: "100%",
                height: 200,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                mb: 2,
              }}
            >
              <ImageIcon size={60} color={alpha(theme.palette.primary.main, 0.7)} />
              <Typography variant="h6" color="primary" sx={{ mt: 2, fontWeight: "medium" }}>
                Drag & Drop your images here
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                or click to browse your files
              </Typography>
            </Box>

            <input
              type="file"
              multiple
              accept="image/*"
              style={{ display: "none" }}
              ref={fileInputRef}
              onChange={handleFileSelect}
            />

            <ActionButton
              variant="outlined"
              color="primary"
              startIcon={<Upload size={18} />}
              onClick={(e) => {
                e.stopPropagation()
                fileInputRef.current?.click()
              }}
            >
              Select Files
            </ActionButton>
          </UploadBox>

          <Box sx={{ mt: 4 }}>
            <Typography variant="h6" fontWeight="medium" sx={{ mb: 2 }}>
              Uploaded Photos ({uploadedImages.length})
            </Typography>

            <ImagePreviewContainer>
              <Typography variant="body2" sx={{ color: "text.secondary", mb: 2 }}>
                <Info size={14} style={{ verticalAlign: "middle", marginRight: 4 }} />
                You need to upload at least 1 photo of your item. High-quality images from multiple angles will attract
                more bidders.
              </Typography>

              <Grid container spacing={2}>
                {uploadedImages.map((img) => (
                  <Grid item xs={6} sm={4} md={3} key={img.id}>
                    <ImagePreview>
                      <Box
                        component="img"
                        src={img.preview || "/placeholder.svg"}
                        alt="Uploaded preview"
                        sx={{
                          width: "100%",
                          height: "100%",
                          objectFit: "cover",
                        }}
                      />
                      <IconButton
                        size="small"
                        onClick={() => handleRemoveImage(img.id)}
                        sx={{
                          position: "absolute",
                          top: 4,
                          right: 4,
                          bgcolor: "rgba(255,255,255,0.9)",
                          color: theme.palette.error.main,
                          "&:hover": {
                            bgcolor: "rgba(255,255,255,1)",
                          },
                          width: 24,
                          height: 24,
                        }}
                      >
                        <X size={14} />
                      </IconButton>
                    </ImagePreview>
                  </Grid>
                ))}

                {uploadedImages.length < 10 && (
                  <Grid item xs={6} sm={4} md={3}>
                    <AddImageBox onClick={() => fileInputRef.current?.click()}>
                      <Plus size={24} color={alpha(theme.palette.primary.main, 0.7)} />
                    </AddImageBox>
                  </Grid>
                )}
              </Grid>

              {uploadedImages.length < 1 && (
                <Alert
                  severity="warning"
                  sx={{
                    mt: 2,
                    borderRadius: 2,
                    "& .MuiAlert-icon": {
                      alignItems: "center",
                    },
                  }}
                >
                  Please upload at least 1 photo to continue
                </Alert>
              )}
            </ImagePreviewContainer>
          </Box>
        </StepContainer>

        {/* Step 2: Description */}
        <StepContainer>
          <StepIcon>
            <FileText size={80} />
          </StepIcon>

          <StepTitle variant="h5">Item Description</StepTitle>

          <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
            <ActionButton
              variant="contained"
              color="primary"
              startIcon={
                isGeneratingDescription ? <CircularProgress size={18} color="inherit" /> : <Sparkles size={18} />
              }
              onClick={handleAutogenerateDescription}
              disabled={isGeneratingDescription || uploadedImages.length === 0}
              sx={{ mr: 2 }}
            >
              {isGeneratingDescription ? "Generating..." : "Auto-Generate Description"}
            </ActionButton>

            <Typography variant="body2" color="text.secondary">
              Let AI create a description based on your photos
            </Typography>
          </Box>

          <TextField
            multiline
            rows={6}
            fullWidth
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe your item in detail. Include condition, features, history, and any other relevant information that would interest potential buyers."
            sx={{
              "& .MuiOutlinedInput-root": {
                borderRadius: 2,
              },
            }}
          />

          {description.trim().length === 0 && (
            <Alert
              severity="info"
              sx={{
                mt: 2,
                borderRadius: 2,
                "& .MuiAlert-icon": {
                  alignItems: "center",
                },
              }}
            >
              A detailed description helps buyers understand what you're selling and increases your chances of a
              successful auction
            </Alert>
          )}
        </StepContainer>

        <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
          <ActionButton
            variant="contained"
            color="primary"
            endIcon={isUploading ? <CircularProgress size={18} color="inherit" /> : <ArrowRight size={18} />}
            onClick={handleContinue}
            disabled={uploadedImages.length < 1 || description.trim().length === 0 || isUploading}
            size="large"
          >
            {isUploading ? "Processing..." : "Continue to Details"}
          </ActionButton>
        </Box>
      </Box>
    </PageContainer>
  )
}

export default UploadAuction;